module.exports = {
    Memory: true,
    IP: '127.0.0.1',
    Port: '27017',
    Database: 'somedb'
  }